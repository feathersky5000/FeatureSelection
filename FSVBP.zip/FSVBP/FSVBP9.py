# -*- coding: utf-8 -*-
"""
Created on Sun Apr 28 20:48:32 2019


@author: Xiaojun Ding
"""




  
import numpy as np
import operator  
import heapq
import math

import time    
from sklearn import metrics    
import pickle as pickle    
import pandas as pd 

from sklearn import preprocessing


from sklearn.datasets import load_iris    
from sklearn import neighbors    
import sklearn    

from sklearn.model_selection import train_test_split


from sklearn.metrics import classification_report

from sklearn import svm  # svm支持向量机



from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression


from sklearn.svm import SVR


from sklearn.ensemble import ExtraTreesClassifier

from sklearn.linear_model import Ridge

from sklearn.linear_model import Lasso



from sklearn.metrics import accuracy_score

from FSVBP_Test import LoadData
 
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2

import datetime


import warnings

warnings.filterwarnings("ignore")


np.set_printoptions(suppress=True)
        
    
    


class FSVBP:    
    
    def __init__(self,K=-1):          
        self.K=K
              
        
        
    def computeWeights( self,X, Y):   
                
        means=[]
        stds=[]
        
        setY=set(Y)
        
        for c in setY:
            idx=np.where(Y==c)
#            print(idx)
            
            cluster=X[idx]
            
#            print('cluster=',type(cluster), cluster)
            mean_c=np.mean(cluster,axis=0)
            std_c=np.std(cluster,axis=0)
            
#            print(mean_c,std_c)
            
            means.append(mean_c)
            stds.append(std_c)
            
#            print('cluster=',cluster)
#            
#            print('mean=',mean_c)
            
        
        diffs=[]
        
        for i in range(len(means)):
            for j in range(i+1,len(means)):
                
#                diff=np.abs(means[i]-means[j])/(np.sqrt(stds[i]*stds[j])+0.0000000001)
                
                
                diff=np.abs(means[i]-means[j])/(np.sqrt(stds[i]+stds[j])+0.0000000001)
                
                diffs.append(diff)
                
#                print(i,j,diff)
                
        diffs=np.array(diffs)
        
#        max_diff=np.max(diffs,axis=0)
        
        mean_diff=np.mean(diffs,axis=0)
        
        w=mean_diff/np.dot(mean_diff,mean_diff)**0.5
        
        return w
    
     
    
    def compute3KNN(self,i_th,X,Y,w):
        
        x_i=X[i_th]
        
        nX = X.shape[0] # shape[0] stands for the num of row 
         
         
        diff = np.tile(x_i, (nX, 1)) - X # Subtract element-wise 
        dw_dist=diff*diff               # multiply element-wise
        dist=np.dot(dw_dist,w)         # weighted distance
        dist=np.sqrt(dist)
        
        
        sortedDistIndices = np.argsort(dist,axis=0 )       
        
        K3=min(self.K*3, nX)
        
        KNN3=sortedDistIndices[1:K3]
        
        
        self.candidate_neighbours[i_th]=KNN3
        
#        
#        self.possible_border[i_th]=0
#        
#        for i in range(len(KNN3)):
#            if Y[KNN3[i]]!=Y[i_th]:
#                self.possible_border[i_th]=1
#                break
#                
#        
##        idx=np.where(Y[KNN3]!=Y[i_th])
##        
##        if len(idx[0])>0:
##            self.possible_border[i_th]=1
###            print(len(idx[0]),'   ',i_th,'   ', idx[0])
        
      
        
        return KNN3
        
        
        

    def computeKNNDistanceAndDerivative(self,i_th,X,Y,w, candidate_neighbour):           
   
        x_i=X[i_th]
                
        X_candidate_neighbour=X[candidate_neighbour,:]
        
        Y_candidate_neighbour=Y[candidate_neighbour]
      
        
        diff = np.tile(x_i, (len(candidate_neighbour), 1)) - X_candidate_neighbour # Subtract element-wise 
        
        dw_dist=diff*diff               # multiply element-wise
        dist=np.dot(dw_dist,w)         # weighted distance
        dist=np.sqrt(dist)
        
        
        sortedDistIndices = np.argsort(dist,axis=0 )       
            
        dw=np.zeros((x_i.shape[0],))
        
        
        borderFlag=0
        
        for neighbour in range(0,self.K):    # do not include itself
            
            k=sortedDistIndices[neighbour]     
            
            if   Y[i_th]!=Y_candidate_neighbour[k]:
                borderFlag=1
            
        if borderFlag==0:
            return [dw,borderFlag]            #  derivative=0 when it is not a border point
        
        
       
        for neighbour in range(0,self.K):    # do not include itself
            
            k=sortedDistIndices[neighbour]        
            
            product_elementwise=(x_i-X_candidate_neighbour[k])*(x_i-X_candidate_neighbour[k])
            
            dist_k=np.sqrt( np.dot( product_elementwise, w) )+0.000001  # avoid dist_k=0
            
            dw_k=1/2*1/dist_k*product_elementwise       
        
            if   Y[i_th]!=Y_candidate_neighbour[k]:   
                dw-=dw_k           
            else:       
                dw+=dw_k
        
        return  [dw,borderFlag]
    
        
    
        
        
        
    def fit( self,X, Y, n_iter=100, w=None ):    
        
        print(" ---------------------fit-------------------")   
        
        
        # w=np.random.random((X.shape[1]))      
        
#        w=np.ones((X.shape[1]))
        
        minError=10000000
        
        if w is None:       
            w=self.computeWeights(X,Y)          
            print('initialize w')
            
        if self.K==-1:
           [K, minError]= self.findMinErrorK(X,Y,w)
           self.K=K         
           
           print('K=',K, ' minError=',minError)
             
    
        
        
        nX = X.shape[0] # shape[0] stands for the num of row 
        
        self.candidate_neighbours=[]       
        
        for i in range(nX):            
            self.candidate_neighbours.append([])

        
        idx=np.where(w>0)
        
        cut_off=len(idx[0])
         
        for t in range(0,n_iter):     
           
            
            if t%5==0:                
                for i in range(nX):   
                    self.compute3KNN(i,X, Y, w)  
                
            
            dw=np.zeros(w.shape)#              
        
            for i in range(nX):         
                
                [dw_i,borderFlag]=self.computeKNNDistanceAndDerivative(i,X, Y, w,self.candidate_neighbours[i])                   
               
                dw+=dw_i      
                                
                
            
            
            norm_dw=np.dot(dw,dw)**0.5
            
            if norm_dw==0:
                print('iteration=',t,' norm_dw=',norm_dw)
                break
            
#            if t>10:
#                print('iteration=',t,' dw=',dw,' w=',w)
            
            if norm_dw>1:
                dw=dw/norm_dw
           
            learning_rate=(n_iter-t)*0.025/n_iter+ 0.0025
            
#            learning_rate=(self.n_iter-t)*0.01/self.n_iter+ 0.005
            
             
            w=w-learning_rate*dw    
           
          
#            errorBefore=self.ErrorCount(X,Y,w)
          
#            if (t%2==0) or (t==n_iter-1):
                
            threshold=0           
                
            squareS0= np.dot(w,w)
            
            sortedW=np.sort(-np.abs(w))
            
            sortedWSquare=sortedW*sortedW
                    
            estimated_cut_off= max(1,int(cut_off*0.9))
            
            squareS=np.sum(sortedWSquare[0:estimated_cut_off])    
            
            for i in range(estimated_cut_off,w.shape[0]):
                
                squareS+=sortedWSquare[i]
                
                if squareS>0.99*squareS0:
                    
                    cut_off=i
                    
                    threshold=-sortedW[i]
                    
                    break
            
            idx=np.where(w<threshold)
            
            w[idx]=0            
           
            
            w=w/np.linalg.norm(w)     
            
            
#            print('np.dot(w,w)=',np.dot(w,w))
            
            
#            errorAfter=self.ErrorCount(X,Y,w)
#            
#            print(t, ' cut off=', cut_off,'  ', errorBefore, '->', errorAfter)
            
            print(t, ' cut off=', cut_off)
            


        
        self.w=w
        
#        print('w=',w)
         
        return w  
    
    
    def predict_one(self, new_x, X, Y,w=None):     
            
        if w is None:
            w=self.w
           
        nX = X.shape[0] # shape[0] stands for the num of row 
         
         
        diff = np.tile(new_x, (nX, 1)) - X # Subtract element-wise 
        dw_dist=diff*diff               # multiply element-wise
        dist=np.dot(dw_dist,w)         # weighted distance
        dist=np.sqrt(dist)
        
        sortedDistIndices = np.argsort(dist,axis=0 )       
        
        classCount = {} # define a dictionary (can be append element)  
        for i in range(self.K):  
          
            voteLabel = Y[sortedDistIndices[i]]  
      
            classCount[voteLabel] = classCount.get(voteLabel, 0) + 1+ 0.1/(i+1)  # more voting power for the nearer neibhgours  
      
      
        maxCount = 0  
        maxIndex=-1
        
        for key, value in classCount.items():  
            if value > maxCount:  
                maxCount = value  
                maxIndex = key  
      
        if maxIndex==-1:
            print(' error ')
            
        return maxIndex   
    
    
    
    def predict(self, predict_x, X, Y, w=None):     
        
#        print(" ---------------------predict-------------------")
        
        if w is None:
            w=self.w
        
        
        if type(predict_x[0])==np.float64 or type(predict_x[0])==np.int64:
            return self.predict_one(predict_x,X,Y,w)    
        else:              
            predict_y=np.zeros((predict_x.shape[0],))
            
            for i in range(predict_x.shape[0]):
                predict_y[i]=self.predict_one(predict_x[i],X,Y,w)      
          
        return predict_y   
    
    
    
    
    
    
    def ErrorCount(self,X,Y,w):      
        
        count=0
        
        nF=X.shape[1]      
        
        px=np.ones((nF,))*100000  
        
        nX = X.shape[0] # shape[0] stands for the num of row 
        
        newX=X.copy()
        
        for i in range(nX):     
            
            predict_x=X[i].copy()
            
            newX[i]=px.copy()            
            
            predict_y=self.predict(predict_x,newX,Y,w)
            
            newX[i]=predict_x.copy()
            
            if predict_y != Y[i]:
                
                count+=1          
                
#            print(i,predict_y,Y[i])
        
        return count
        
  
            
            
    def findMinErrorK(self,X,Y, w, minK=3,maxK=7):
        
        bc=np.array(np.bincount(Y),dtype=int)   
        
        print('# in class',bc)
        
        minC=min(bc)
        
        maxK=max(3,min(minC-1,maxK))
        
        print('findMinErrorK ', minC,minK,maxK)
        
        minErrorK=3
        minErrorCount=X.shape[0]
        
        for i in range(maxK,minK-1,-2):
            
            self.K=i
            c=self.ErrorCount(X,Y,w)
            if c<minErrorCount:
                minErrorCount=c
                minErrorK=self.K
                
#            print('k=',i,'error=',c)
                
            
#        print('min k=',minErrorK,' min error=',minErrorCount)
        
        return [minErrorK,minErrorCount]
            
          
        
    
    def w_count(self,w):
    
        idx=np.where(w>0)
        
        count=len(idx[0])
           
        print('# features='+str(len(w))+' #selected features ='+str(count)+ ' ratio='+str(count/len(w)))
              
        return count
    
    
      
#--------------------------------------------------------------

   
    

class PerformanceRecord:
    
    def __init__(self):      
        
        self.records={}     
        
        self.record_mean={}
        
        

    def Performance(self,y,y_predict):
        
        performanceStr=classification_report(y, y_predict)
        
        items=performanceStr.split( )
    
        precision=float(items[len(items)-4])
        recall=float(items[len(items)-3])
        fscore=float(items[len(items)-2])
        
        acc=round(accuracy_score(y, y_predict),3)
        
        return [acc, precision, recall, fscore]
    
    
    def Record(self,y,y_predict, title='',otherInfo=[]):       
        
            
        p=self.Performance(y,y_predict)
        
        p=p+otherInfo
        
        if  title not in self.records:  
            self.records[title]=[]
            
        self.records[title].append(p)     
       
        print(title)    
         
        print(p)    
        
        print(' ')
        
        
        
    def Record2(self, title='',info=[]):     
        
        if  title not in self.records:  
            self.records[title]=[]
            
        self.records[title].append(info)     
       
        print(title)    
         
        print(info)    
        
        print(' ')
        
    
    
    def ComputeMeanOfRecords(self):
        
         for k,v in self.records.items():
        
             arr=np.array(v)    
             
             self.record_mean[k]=np.round(np.mean(arr,axis=0),decimals=3)
        
        
        
    def Save(self, filename='performance.txt'):  

        self.ComputeMeanOfRecords()
        
        
        file = open(filename,'w')#dict转txt
        
        
        for k,v in self.records.items():
            
            print(k)
            print(str(v))
            
            file.write(k+'  '+str(v))           
                
            file.write(' mean=  '+str(self.record_mean[k]))                
                
    
            file.write('\n\n')
            
        file.close()

   
        


        
def SelectFeatures(X,Y,nK=10,method='extraTrees'):


    nK=min(X.shape[1]-2,nK)
    
    if method=='chi2':  # Input X must be non-negative
                
       try:
            
            model = SelectKBest(chi2, k=nK)
            
            model.fit_transform(X, Y)
            
            idx=model.get_support(indices=True)
            
            return [idx]
       except:
           return [[]]
    
    
    if method=='extraTrees':
        
        model = ExtraTreesClassifier()
        model.fit(X, Y)
#        print('------------ExtraTreesClassifier------------')
#        # display the relative importance of each attribute
#        print(model.feature_importances_)
        
        
        idx=np.where(model.feature_importances_>0)
        
        return idx
        
        
    if method=='ridge': 
        
        ridge = Ridge(alpha=1)
        ridge.fit(X, Y)
#        print('------------ridge------------')
#        print (ridge.coef_)
#        print (ridge.intercept_)
        
        absW=np.abs(ridge.coef_)
        
        
        
        squareS0= np.dot(absW,absW)
        
        sortedW=np.sort(-absW)
        
        sortedWSquare=sortedW*sortedW
        
        squareS=0  
        
        for i in range(0,absW.shape[0]):
            
            squareS+=sortedWSquare[i]
            
            if squareS>0.99*squareS0:              
              
                
                threshold=-sortedW[i]
                
                break
        
        idx=np.where(absW>threshold)
        
        return idx        
    
    if method=='lasso': 
        
        alphas=[1,0.1,0.01,10]
        
        for k in range(len(alphas)):
            
            lasso = Lasso(alpha=alphas[k])
            lasso.fit(X, Y)
            
            absW=np.abs(lasso.coef_)
     
            idx=np.where(absW>0)
            
            if len(idx[0])>0:
                return idx
        
#        print('lasso', idx[0])
        
        return []      
    
    
    if method=='FSVBP': 
    
        model = FSVBP()    
         
        w=model.fit(X, Y)   
        
        idx=np.where(w>0)
        
        return idx    
        
        
    if method=='rfe logistic regression': 
        
        model = LogisticRegression()
   
    if method=='rfe svm linear': 
        
        model = svm.SVC(kernel='linear')
    
    if method=='rfe logistic regression' or method=='rfe svm linear': 
       
        # create the RFE model and select 3 attributes
        rfe = RFE(model, nK)
        rfe = rfe.fit(X, Y)
        # summarize the selection of the attributes
#        print('------------rfe logistic regression------------')
#        print(rfe.support_)
#        print(rfe.ranking_)
        
       
        idx=np.where(rfe.support_==True)
        
        return idx
        
        

 
    
    
    
def TestPerformance(X,Y, testTimes=10, bScaled=0, _test_size=0.1,n_iter=100,bRunRFE=False):
    
    
    if bScaled==1:
        X_scaled = preprocessing.scale(X)        
        X=X_scaled
        
      
    print('--------------------START-----------')
    
    performances=PerformanceRecord()
    
    
    ratio=0
  
    
    for iter in range(testTimes):       
    
        X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=_test_size)        
        
        model = FSVBP( )       
        
        
        #------------------------------------------------------
        
        starttime = datetime.datetime.now()
         
        w=model.fit(X_train, y_train,n_iter=n_iter)   
        
        stime=(datetime.datetime.now() - starttime).seconds
        
#        print(w)
        
        nK=model.w_count(w)
        
        ratio+=nK/len(w)         
        
        predict_y2=model.predict(X_test,X_train,y_train,w)          
        
        performances.Record(y_test, predict_y2,title='FSVBP KNN',otherInfo=[nK,(datetime.datetime.now() - starttime).seconds ])  
        
      
        
           
      
        
        
        #-----------------------------------------
        
        starttime = datetime.datetime.now()
         
        originalW=np.ones((X_train.shape[1],))
        
#        print(originalW)
        
        predict_y=model.predict(X_test,X_train,y_train,originalW)    
        
        performances.Record(y_test, predict_y,title='original KNN',otherInfo=[X_train.shape[1],(datetime.datetime.now() - starttime).seconds])  
        
        
        #-----------------------------------------
        
        starttime = datetime.datetime.now()
        
        singleWeightedW=model.computeWeights(X_train,y_train)
        
#        print(singleWeightedW)
         
        predict_y=model.predict(X_test,X_train,y_train,singleWeightedW)    
        
        performances.Record(y_test, predict_y,title='single weighted KNN',otherInfo=[X_train.shape[1],(datetime.datetime.now() - starttime).seconds])  
        
        #----------------------------------------
       
           


       #---------------------------
       
        starttime = datetime.datetime.now()
        
        clf = svm.SVC(kernel='rbf')  #rbf核函数        
        clf.fit(X=X_train, y=y_train)  # 训练模型。参数sample_weight为每个样本设置权重。应对非均衡问题
        svm_y = clf.predict(X_test)  # 使用模型预测值     
        
#        print(clf._get_coef())
        performances.Record(y_test, svm_y,title='rbf SVM',otherInfo=[X_train.shape[1],(datetime.datetime.now() - starttime).seconds])  
        
        
        #---------------------------
       
        starttime = datetime.datetime.now()
        
        idx = SelectFeatures(X=X_train, Y=y_train,nK=1000,method='extraTrees')  
        
        
        stime=(datetime.datetime.now() - starttime).seconds
        
        originalW=np.zeros((X_train.shape[1],))
        
        originalW[idx]=1        
        
#        print(originalW)
        
        predict_y=model.predict(X_test,X_train,y_train,originalW)    
        
        performances.Record(y_test, predict_y,title='extraTrees+KNN',otherInfo=[len(idx[0]),(datetime.datetime.now() - starttime).seconds]) 
        
        
        
        #------------------------------------------
       
        starttime = datetime.datetime.now()
        
#        idx = SelectFeatures(X=X_train, Y=y_train,nK=1000,method='extraTrees')                
       
        
        clf = svm.SVC(kernel='rbf')  #rbf核函数        
        clf.fit(X=X_train[:,idx[0]], y=y_train)  # 训练模型。参数sample_weight为每个样本设置权重。应对非均衡问题
        svm_y = clf.predict(X_test[:,idx[0]])  # 使用模型预测值
        
        performances.Record(y_test, svm_y,title='extraTrees+rbf svm',otherInfo=[len(idx[0]),(datetime.datetime.now() - starttime).seconds+stime]) 
        
        
          
    
        #---------------------------
       
        starttime = datetime.datetime.now()
        
        idx = SelectFeatures(X=X_train, Y=y_train,nK=1000,method='chi2')  
        
        if len(idx[0])>0:
            
            originalW=np.zeros((X_train.shape[1],))
            
            originalW[idx]=1    
            
            predict_y=model.predict(X_test,X_train,y_train,originalW)    
            
            performances.Record(y_test, predict_y,title='chi2+KNN',otherInfo=[len(idx[0]),(datetime.datetime.now() - starttime).seconds]) 
            
        
        
        #------------------------------------------
       
        starttime = datetime.datetime.now()
        
        idx = SelectFeatures(X=X_train, Y=y_train,nK=1000,method='chi2')    

        if len(idx[0])>0:   
        
            clf = svm.SVC(kernel='rbf')  #rbf核函数        
            clf.fit(X=X_train[:,idx[0]], y=y_train)  # 训练模型。参数sample_weight为每个样本设置权重。应对非均衡问题
            svm_y = clf.predict(X_test[:,idx[0]])  # 使用模型预测值
            
            performances.Record(y_test, svm_y,title='chi2+rbf svm',otherInfo=[len(idx[0]),(datetime.datetime.now() - starttime).seconds]) 
            
        
        #---------------------------
        
    
         #---------------------------
       
        starttime = datetime.datetime.now()
        
        idx = SelectFeatures(X=X_train, Y=y_train,nK=1000,method='ridge')  
        
        originalW=np.zeros((X_train.shape[1],))
        
        originalW[idx]=1        
        
#        print(originalW)
        
        predict_y=model.predict(X_test,X_train,y_train,originalW)    
        
        performances.Record(y_test, predict_y,title='ridge+KNN',otherInfo=[len(idx[0]),(datetime.datetime.now() - starttime).seconds]) 
        
        
        
        #------------------------------------------
       
        starttime = datetime.datetime.now()
        
        idx = SelectFeatures(X=X_train, Y=y_train,nK=1000,method='ridge')                
       
        
        clf = svm.SVC(kernel='rbf')  #rbf核函数        
        clf.fit(X=X_train[:,idx[0]], y=y_train)  # 训练模型。参数sample_weight为每个样本设置权重。应对非均衡问题
        svm_y = clf.predict(X_test[:,idx[0]])  # 使用模型预测值
        
        performances.Record(y_test, svm_y,title='ridge+rbf svm',otherInfo=[len(idx[0]),(datetime.datetime.now() - starttime).seconds]) 
        
        
        #---------------------------

       
        starttime = datetime.datetime.now()
        
        idx = SelectFeatures(X=X_train, Y=y_train,nK=1000,method='lasso')      
        
        stime=(datetime.datetime.now() - starttime).seconds

        if len(idx[0])>0:
            
            originalW=np.zeros((X_train.shape[1],))
        
            originalW[idx]=1        
            
    #        print(originalW)
            
            predict_y=model.predict(X_test,X_train,y_train,originalW)  
            
            
            performances.Record(y_test, predict_y,title='lasso+ KNN',otherInfo=[len(idx[0]),(datetime.datetime.now() - starttime).seconds]) 
            
            
        #---------------------------

       
        starttime = datetime.datetime.now()
        
#        idx = SelectFeatures(X=X_train, Y=y_train,nK=1000,method='lasso')        

        if len(idx[0])>0:
        
            clf = svm.SVC(kernel='rbf')  #rbf核函数        
            clf.fit(X=X_train[:,idx[0]], y=y_train)  # 训练模型。参数sample_weight为每个样本设置权重。应对非均衡问题
            svm_y = clf.predict(X_test[:,idx[0]])  # 使用模型预测值
            
            performances.Record(y_test, svm_y,title='lasso+rbf svm',otherInfo=[len(idx[0]),(datetime.datetime.now() - starttime).seconds+stime]) 
            
        
        
        #--------------------- the following methods are very slow for big data------       
     
        if bRunRFE:
           
            starttime = datetime.datetime.now()
            
            idx = SelectFeatures(X=X_train, Y=y_train,nK=nK,method='rfe logistic regression')  
            
            stime=(datetime.datetime.now() - starttime).seconds
            
            originalW=np.zeros((X_train.shape[1],))
            
            originalW[idx]=1        
            
    #        print(originalW)
            
            predict_y=model.predict(X_test,X_train,y_train,originalW)    
            
            performances.Record(y_test, predict_y,title='rfe logistic regression+KNN',otherInfo=[len(idx[0]),(datetime.datetime.now() - starttime).seconds]) 
            
            
            
            #------------------------------------------
           
            starttime = datetime.datetime.now()       
            
            clf = svm.SVC(kernel='rbf')  #rbf核函数        
            clf.fit(X=X_train[:,idx[0]], y=y_train)  # 训练模型。参数sample_weight为每个样本设置权重。应对非均衡问题
            svm_y = clf.predict(X_test[:,idx[0]])  # 使用模型预测值
            
            performances.Record(y_test, svm_y,title='rfe logistic regression+rbf svm',otherInfo=[len(idx[0]),(datetime.datetime.now() - starttime).seconds+stime]) 
            
            
        
           #---------------------------
           
            starttime = datetime.datetime.now()
            
            idx = SelectFeatures(X=X_train, Y=y_train,nK=nK,method='rfe svm linear')  
            
            stime=(datetime.datetime.now() - starttime).seconds
            
            originalW=np.zeros((X_train.shape[1],))
            
            originalW[idx]=1        
            
    #        print(originalW)
            
            predict_y=model.predict(X_test,X_train,y_train,originalW)    
            
            performances.Record(y_test, predict_y,title='rfe svm linear+KNN',otherInfo=[len(idx[0]),(datetime.datetime.now() - starttime).seconds]) 
            
            
            
            #------------------------------------------
           
            starttime = datetime.datetime.now()           
            
            clf = svm.SVC(kernel='rbf')  #rbf核函数        
            clf.fit(X=X_train[:,idx[0]], y=y_train)  # 训练模型。参数sample_weight为每个样本设置权重。应对非均衡问题
            svm_y = clf.predict(X_test[:,idx[0]])  # 使用模型预测值
            
            performances.Record(y_test, svm_y,title='rfe svm linear+rbf svm',otherInfo=[len(idx[0]),(datetime.datetime.now() - starttime).seconds+stime]) 
            
            
        
        
        
        


    ratio/=testTimes
   
    
    print('precision  recall f-score')
    print(performances)
    
    print('#features=', X.shape[1], ' average ratio ', ratio)
          
    return performances








            
        
        

def TestPerformance2(X,Y, nF=10, testTimes=10, bScaled=0, _test_size=0.1, features=[0]):
    
    
    if bScaled==1:
        X_scaled = preprocessing.scale(X)        
        X=X_scaled
        
      
    print('--------------------START-----------')     

   
    methods=['extraTrees','chi2','ridge','lasso','rfe svm linear','rfe logistic regression','FSVBP']


    performances=PerformanceRecord()
    
    for n in range(testTimes):       
        
        print('-------------------- ',n,' -----------')   
    
        X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=_test_size)    
        
        
        for i in range(len(methods)):
            
            idx = SelectFeatures(X=X_train, Y=y_train,nK=nF,method=methods[i])  
            
            if  len(idx[0])==0:   
                continue
            
            bHit=1
            
            for k in range(len(features)):
                if features[k] not in idx[0]:
                    bHit=0
                    break                
                
            performances.Record2(title=methods[i],info=[bHit,len(idx[0])])           
    
    
    return performances
        
#-------------------------------------        


 
def TestPerformance22(datasetName='', nF=10, testTimes=10, bScaled=0, _test_size=0.1, features=[0]):
    
    
    [X,Y]=LoadData(datasetName)          
    
    
    return TestPerformance2(X,Y,nF,testTimes,bScaled,_test_size,features)
               
        
        
#---------------------------------     

    
def SimulationTest():
    
    simulationTest={}
    simulationTest['s1']=[5,[0,2,4]]
    simulationTest['s2']=[20,[0,99]]
    simulationTest['s3']=[10,[0,1,2,3,4]]    
    simulationTest['s4']=[5,[0,2]]
    simulationTest['s5']=[5,[0,2,4]]   
    simulationTest['s6']=[5,[0,19]]
    
    
    for k,v in simulationTest.items():
        
        datasetName=k
      
        performances0=TestPerformance22(datasetName, nF=v[0], testTimes=10, bScaled=0, _test_size=0.1,features=v[1])
        
        performances0.Save(datasetName+'_p2.txt')
        


#---------------------------------

#SimulationTest()
#    
#-----------------------------------------------------------------------------
        
        
def TestP(datasetName,testTimes=10,bScaled=1,n_iter=100,bRunRFE=False):

    [X,Y]=LoadData(datasetName)
    
    if (X.shape[0]>1000) and (X.shape[1]>10000):
        print(datasetName, 'nX=',X.shape[0], ' too big')
        return
    
    performances=TestPerformance(X,Y, testTimes=testTimes, bScaled=bScaled, _test_size=0.1,n_iter=n_iter,bRunRFE=bRunRFE)
    
    performances.Save(datasetName+'_'+str(bScaled)+'.txt')     
    
    
   
##
#TestP('Iris',bScaled=0, testTimes=10, n_iter=100,bRunRFE=True) 
##
#
#TestP('wdbc',bScaled=0, testTimes=10, n_iter=100,bRunRFE=True) 
    
#[X,Y]=LoadData('sonar')
#

TestP('sonar',bScaled=0, testTimes=10, n_iter=100,bRunRFE=True) 

#TestP('breast_cancer',bScaled=0, testTimes=10, n_iter=100,bRunRFE=True)   


#
#TestP('Wine',bScaled=0, testTimes=10, n_iter=100,bRunRFE=True)   


#
#TestP('Car Evaluation',bScaled=0, testTimes=10, n_iter=100,bRunRFE=True)   



#TestP('winequality-red',bScaled=0, testTimes=10, n_iter=100)   

#
#TestP('Digits',bScaled=0, testTimes=10, n_iter=100,bRunRFE=True)

#TestP('Deng',bScaled=0, n_iter=100)      

#TestP('Wang',bScaled=0, n_iter=100)       

#[X,Y]=LoadData('Iris')
#
#selector=SelectKBest(chi2, k=2)
#
#x_new = selector.fit_transform(X, Y)
#
#idx=selector.get_support(indices=True)
#
#x_new = SelectKBest(chi2, k=2).fit(X, Y)
#print(x_new)
    
#----------------------------------------------------------------------
    
    
    

import sys

def main(argv):   
    print('---------running---------')
    
    now=time.time()   
     
    print(sys.argv)
    
    if len(sys.argv)>1 and (sys.argv[1]=='SimulationTest'):
        SimulationTest()
    
    if len(sys.argv)>2:    
        
        TestP(datasetName=sys.argv[1],testTimes=int(sys.argv[2]), bScaled=int(sys.argv[3]), n_iter=int(sys.argv[4]) )
     
            
    print('running time ',time.time()-now)
            
       


if __name__ == '__main__':
    main(sys.argv)
    
       
    
       
    


def TestT(datasetName,bScaled=0):
    
    
    performances=PerformanceRecord()
    
    [X,Y]=LoadData(datasetName)
    
    if bScaled==1:
        X_scaled = preprocessing.scale(X)        
        X=X_scaled
     
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.1)        
        
    model = FSVBP( )       
    
    
    #------------------------------------------------------
    
    w=None
    
    for i in range(20):        
      
        starttime = datetime.datetime.now()  
        
        if i==0:
            w=model.fit(X_train, y_train,n_iter=0,w=w)   
        else:
            w=model.fit(X_train, y_train,n_iter=10,w=w)   
        
        nK=model.w_count(w)       
       
        
        predict_y2=model.predict(X_test,X_train,y_train,w)          
        
        performances.Record(y_test, predict_y2,title='FSVBP KNN',otherInfo=[nK,(datetime.datetime.now() - starttime).seconds ])  
        
        
        
        
#[X,Y]=LoadData('Deng')

#TestT('Wang')   


#TestT('Deng')   





